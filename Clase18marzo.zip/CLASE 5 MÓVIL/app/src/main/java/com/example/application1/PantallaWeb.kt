package com.example.application1

import android.os.Bundle
import android.webkit.WebViewClient
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.application1.databinding.ActivityPantallaWebBinding

class PantallaWeb : AppCompatActivity() {

    lateinit var binding: ActivityPantallaWebBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //inicializar el binding
        binding = ActivityPantallaWebBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //cargar la pagina web
        binding.webview.webViewClient = WebViewClient()
        binding.webview.loadUrl("https://www.javeriana.edu.co/inicio")


    }

}