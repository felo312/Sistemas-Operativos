package com.example.application1

import android.content.Intent
import android.os.Bundle
import android.util.Log
//import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.application1.databinding.ActivityMainBinding
import android.widget.Toast

//import androidx.core.view.ViewCompat
//import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //manejo de binding:
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)



        binding.Boton1.setOnClickListener {

            //Intent(donde estoy, hacia donde voy)
            val nombre = binding.NombreTxt.text.toString()
            val edadText = binding.EdadTxt.text.toString()
            val pesoText = binding.PesoTxt.text.toString()

            if (nombre.isBlank() || edadText.isBlank() || pesoText.isBlank()) {
                Toast.makeText(this, "Por favor ingrese todos los datos", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            val caja = Bundle()
            caja.putString("Nombre", nombre)
            caja.putInt("Edad", edadText.toInt())
            caja.putFloat("Estatura", pesoText.toFloat())

            val i = Intent(this, Pantalla2::class.java)
            i.putExtra("paquete", caja)

            startActivity(i)
        }


        binding.Boton2.setOnClickListener {
            startActivity(Intent(this, Gps::class.java))
        }

    }

    private fun mostrarMensaje (text:String): Int{
        var msj = Toast.makeText(baseContext, "HOLAAA", Toast.LENGTH_LONG)
        msj.show()
        return 1

    }
}