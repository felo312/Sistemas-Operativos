package com.example.application1

import android.R
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Bundle
import android.provider.ContactsContract
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.application1.PantallaWeb
import com.example.application1.databinding.ActivityPantalla2Binding
import org.json.JSONObject
import com.example.application1.Miscellaneous
import com.example.application1.Miscellaneous.Companion.PERMISSION_CAMERA
import com.example.application1.Miscellaneous.Companion.PERMISSION_READ_CONTACTS

class Pantalla2 : AppCompatActivity(), AdapterView.OnItemSelectedListener {

    lateinit var binding: ActivityPantalla2Binding
    var nivel = ""

    //para adapter personalizado
    var mProjection: Array<String>? = null
    var mCursor: Cursor? = null
    var mContactsAdapter: ContactsAdapter? = null




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPantalla2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        val nombre = intent.getBundleExtra("paquete")?.getString("Nombre")
        binding.textView.text = nombre
        binding.spinner.onItemSelectedListener = this

        //leer contactos
        mProjection = arrayOf(ContactsContract.Profile._ID, ContactsContract.Profile.DISPLAY_NAME_PRIMARY)
        mContactsAdapter = ContactsAdapter(this, null, 0)
        binding.lista?.adapter = mContactsAdapter



        /*

         //Llenar la lista
        val json = JSONObject(Miscellaneous.loadJSONFromAsset(baseContext,"paises.json"))
        val paisesJsonArray = json.getJSONArray("paises")
        val nombresPaises = arrayOfNulls<String>(paisesJsonArray.length())
        for (i in 0 until paisesJsonArray.length()) {
            val jsonObject = paisesJsonArray.getJSONObject(i)
            nombresPaises[i] = jsonObject.getString("nombre_pais")
        }



        //adaptador estandar, se pueden hacer personalizados que se usaran en el parcial
        val adapter = ArrayAdapter(this,
            R.layout.simple_list_item_1, nombresPaises)
        binding.lista.adapter = adapter




        //listener
        binding.lista.setOnItemClickListener(object : AdapterView.OnItemClickListener {
            override fun onItemClick(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Toast.makeText(baseContext, "hola mundo " + nombresPaises[position], Toast.LENGTH_SHORT).show()
                val algo = 2 //esto es lo personalizable
            }
        })


         */



        //programar botones
        binding.button2.setOnClickListener {
            startActivity(Intent(this, PantallaWeb::class.java))
        }


        binding.button1.setOnClickListener {
            if (nivel.isNotBlank()) {
                val paquete = Bundle()
                paquete.putString("Nombre", nombre)  // Asegurar que no sea null
                paquete.putString("Profesion", nivel) // Enviamos el nivel como "Profesion"

                val intent = Intent(this, PantallaFrame::class.java)
                intent.putExtra("paquete", paquete)

                startActivity(intent)
            } else {
                Toast.makeText(
                    baseContext,
                    "Seleccione un nivel educativo",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }




        //dentro del onCreate
        when {
            ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.READ_CONTACTS
            ) == PackageManager.PERMISSION_GRANTED -> {
                // You can use the API that requires the permission.
                // performAction(...)
            }
            ActivityCompat.shouldShowRequestPermissionRationale(
                this, android.Manifest.permission.READ_CONTACTS) -> {
                // In an educational UI, explain to the user why your app requires this
                // permission for a specific feature to behave as expected, and what
                // features are disabled if it's declined.
                // showInContextUI(...)
                pedirPermiso(this, android.Manifest.permission.READ_CONTACTS, "", PERMISSION_READ_CONTACTS )

            }
            else -> {
                // You can directly ask for the permission.
                pedirPermiso(this, android.Manifest.permission.READ_CONTACTS, "", PERMISSION_READ_CONTACTS )

            }
        }






    }


    private fun pedirPermiso(context: Activity, permiso: String, justificacion: String,
                             idCode: Int) {
        if (ContextCompat.checkSelfPermission(context, permiso)
            != PackageManager.PERMISSION_GRANTED
        ) {
            //metodo de android
            requestPermissions(arrayOf(permiso), idCode)
        }

    }


    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            PERMISSION_READ_CONTACTS -> {
                // If request is cancelled, the result arrays are empty.
                if ((grantResults.isNotEmpty() &&
                            grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    // Permission is granted. Continue the action or workflow
                    // in your app.
                    mCursor = contentResolver.query(
                        ContactsContract.Contacts.CONTENT_URI, mProjection, null, null, null
                    )
                    mContactsAdapter?.changeCursor(mCursor)
                } else {
                    // Explain to the user that the feature is unavailable
                    Toast.makeText(baseContext, "experiencia de usuario disminuida!!", Toast.LENGTH_SHORT).show()
                }
                return
            }


            PERMISSION_CAMERA -> {
                // If request is cancelled, the result arrays are empty.
                if ((grantResults.isNotEmpty() &&
                            grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    // Permission is granted. Continue the action or workflow
                    // in your app.
                    //se llena el cursor

                } else {
                    // Explain to the user that the feature is unavailable
                }
                return
            }


            else -> {
                // Ignore all other requests.
            }
        }
    }



    override fun onItemSelected(parent: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
        if(parent?.selectedItemId?.toInt() != 0){
            nivel = parent?.selectedItem.toString()
        }
        Toast.makeText(baseContext,
            "Selección: " + parent?.selectedItemId + "," + parent?.selectedItem,
            Toast.LENGTH_SHORT)
            .show()

    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
        //no se hace nada
    }
}