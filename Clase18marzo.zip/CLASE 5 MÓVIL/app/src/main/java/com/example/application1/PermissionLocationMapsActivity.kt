package com.example.application1

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.application1.Miscellaneous.Companion.PERMISSION_CAMERA
import com.example.application1.Miscellaneous.Companion.PERMISSION_READ_CONTACTS
import com.example.application1.databinding.ActivityPantalla2Binding
import com.example.application1.databinding.ActivityPermissionLocationMapsBinding


class PermissionLocationMapsActivity : AppCompatActivity() {
    lateinit var binding: ActivityPermissionLocationMapsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionLocationMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)





        binding.button6.setOnClickListener {

            startActivity(Intent(this, PantallaWeb::class.java))

            // T0DO ESTO VA DEBAJO EN LA PANTALLA A LA QUE LLEVA PRESIONAR CONTACTO, NO ACA
            when {
                ContextCompat.checkSelfPermission(
                    this, android.Manifest.permission.READ_CONTACTS
                ) == PackageManager.PERMISSION_GRANTED -> {
                    // You can use the API that requires the permission.
                    // performAction(...)
                }
                ActivityCompat.shouldShowRequestPermissionRationale(
                    this, android.Manifest.permission.READ_CONTACTS) -> {
                    // In an educational UI, explain to the user why your app requires this
                    // permission for a specific feature to behave as expected, and what
                    // features are disabled if it's declined.
                    // showInContextUI(...)
                    pedirPermiso(this, android.Manifest.permission.READ_CONTACTS, "", PERMISSION_READ_CONTACTS )

                }
                else -> {
                    // You can directly ask for the permission.
                    pedirPermiso(this, android.Manifest.permission.READ_CONTACTS, "", PERMISSION_READ_CONTACTS )

                }
            }
        }





    }


    private fun pedirPermiso(context: Activity, permiso: String, justificacion: String,
                             idCode: Int) {
        if (ContextCompat.checkSelfPermission(context, permiso)
            != PackageManager.PERMISSION_GRANTED
        ) {
            //metodo de android
            requestPermissions(arrayOf(permiso), idCode)
        }

    }


    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            PERMISSION_READ_CONTACTS -> {
                // If request is cancelled, the result arrays are empty.
                if ((grantResults.isNotEmpty() &&
                            grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    // Permission is granted. Continue the action or workflow
                    // in your app.
                } else {
                    // Explain to the user that the feature is unavailable
                    Toast.makeText(baseContext, "experiencia de usuario disminuida!!", Toast.LENGTH_SHORT).show()
                }
                return
            }
            else -> {
                // Ignore all other requests.
            }
        }
    }


}