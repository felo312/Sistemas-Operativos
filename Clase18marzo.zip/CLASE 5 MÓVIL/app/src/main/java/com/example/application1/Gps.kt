package com.example.application1

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.application1.databinding.ActivityGpsBinding
import com.google.android.gms.location.*
import com.example.application1.Miscellaneous.Companion.PERMISSION_GPS
import com.example.application1.Miscellaneous.Companion.RADIUS_OF_EARTH_KM
import kotlin.math.*

class Gps : AppCompatActivity() {

    private lateinit var binding: ActivityGpsBinding
    private lateinit var mFusedLocationProviderClient: FusedLocationProviderClient
    private lateinit var mLocationCallback: LocationCallback
    private lateinit var mLocationRequest: LocationRequest

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGpsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        mLocationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10000)
            .setMinUpdateIntervalMillis(3000)
            .build()

        verificarPermisoUbicacion()

        mLocationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                locationResult.lastLocation?.let { actualizarUIConUbicacion(it.latitude, it.longitude, it.altitude) }
            }
        }
    }

    private fun verificarPermisoUbicacion() {
        if (tienePermisoUbicacion()) {
            obtenerUbicacion()
            startLocationUpdates()
        } else {
            pedirPermisoUbicacion()
        }
    }

    private fun tienePermisoUbicacion(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun pedirPermisoUbicacion() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), PERMISSION_GPS)
    }

    private fun startLocationUpdates() {
        if (tienePermisoUbicacion()) {
            mFusedLocationProviderClient.requestLocationUpdates(mLocationRequest, mLocationCallback, Looper.getMainLooper())
        } else {
            Toast.makeText(this, "No se puede iniciar actualización sin permiso", Toast.LENGTH_SHORT).show()
        }
    }

    private fun obtenerUbicacion() {
        if (tienePermisoUbicacion()) {
            mFusedLocationProviderClient.lastLocation.addOnSuccessListener { location ->
                location?.let {
                    actualizarUIConUbicacion(it.latitude, it.longitude, it.altitude)
                } ?: Toast.makeText(this, "No se pudo obtener la ubicación", Toast.LENGTH_SHORT).show()
            }.addOnFailureListener {
                Toast.makeText(this, "Error al obtener ubicación", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Permiso de ubicación no concedido", Toast.LENGTH_SHORT).show()
        }
    }

    private fun actualizarUIConUbicacion(lat: Double, long: Double, alt: Double) {
        Log.i("LOCATION", "Ubicación actual: Lat: $lat, Long: $long, Alt: $alt")

        binding.Altitud.text = "Altitud: $alt"
        binding.Latitud.text = "Latitud: $lat"
        binding.Longitud.text = "Longitud: $long"

        val distanciaKm = distance(lat, long, 4.7016, -74.1469)
        binding.Distancia.text = "Distancia al aeropuerto: $distanciaKm km"
    }

    private fun distance(lat1: Double, long1: Double, lat2: Double, long2: Double): Double {
        val latDistance = Math.toRadians(lat1 - lat2)
        val lngDistance = Math.toRadians(long1 - long2)
        val a = sin(latDistance / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(lngDistance / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return (RADIUS_OF_EARTH_KM * c * 100.0).roundToInt() / 100.0
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_GPS && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            obtenerUbicacion()
            startLocationUpdates()
        } else {
            Toast.makeText(this, "Permiso de ubicación denegado", Toast.LENGTH_SHORT).show()
        }
    }
}
