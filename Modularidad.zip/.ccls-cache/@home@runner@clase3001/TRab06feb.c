/***** Captura de Tiempos ***********
Autor: Juan Felipe Galvis Vargas
Fecha: 6 febrero 2024
Materia: Sistemas Operativos
Pontificia Universidad Javeriana
Tema: Captura de tiempo de algoritmosgcc
                                - Multiplicación de Matrices
                                - Creación de Makefile (compilación
automatizada)
*************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include "biblio02.h"

#define SZ 6

struct timeval start, stop;

void inicio_tiempo() { gettimeofday(&start, NULL); }

void fin_tiempo() {
  gettimeofday(&stop, NULL);
  stop.tv_sec -= start.tv_sec;
  printf("%9.0f µs\n", (double)(stop.tv_sec * 1000000 + stop.tv_usec));
}

void impresionMatriz(int M[SZ][SZ]) {
  for (int i = 0; i < SZ; i++) {
    for (int j = 0; j < SZ; j++) {
      printf(" %d ", M[i][j]);
    }
    printf("\n");
  }
  printf("\n");
}

int llenarMatriz(int M[SZ][SZ]) {

  for (int i = 0; i < SZ; i++) {
    for (int j = 0; j < SZ; j++) {
      M[i][j] = 1 + rand() % 7;
    }
  }
}

void multMatriz() {

  int matriz01[SZ][SZ];
  int matriz02[SZ][SZ];

  for (int i = 0; i < SZ; i++) {
    for (int j = 0; j < SZ; j++) {
      int res = i*j;
    }
  }
  for (int i = 0; i < SZ; i++) {
    for (int j = 0; j < SZ; j++) {
    }
  }
}	

int main() {

  srand(time(NULL));

  int matriz01[SZ][SZ];
  int matriz02[SZ][SZ];

  llenarMatriz(matriz01);
  llenarMatriz(matriz02);

  impresionMatriz(matriz01);
  impresionMatriz(matriz02);

  //multMatriz();	

  return 0;
}